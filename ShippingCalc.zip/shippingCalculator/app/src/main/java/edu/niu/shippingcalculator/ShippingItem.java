package edu.niu.shippingcalculator;

public class ShippingItem {

    // Constants
    static final Double BASE_AMOUNT = 3.00,
                        ADDED_AMOUNT = 0.50,
                        EXTRA_OUNCES = 4.0;

    static final Integer BASE_WEIGHT = 16;

    //data members

    private Integer weight;
    private Double baseCost, addedCost, totalCost;

    public ShippingItem() {
        weight = 0;
        baseCost = BASE_AMOUNT;
        addedCost = 0.00;
        totalCost = 0.00;
    } // end of constuctor

    public void setWeight(Integer newWeight) {
        weight = newWeight;
        computeCost();
    }//end setWeight

    public Double getBaseCost() {
        return baseCost;
    }

    public Double getAddedCost() {
        return addedCost;
    }

    public Double getTotalCost() {
        return totalCost;
    }

    // add the compute cost method
    public void computeCost()
    {
      // calc baseCost
      baseCost = BASE_AMOUNT;

      // cover the case of 0 ounces
        if(weight <=0)
            baseCost = 0.0;

        // worked on addedCost
        addedCost = 0.0;
        //cover the case of mroe than 16 oz
        if(weight > BASE_WEIGHT)
            addedCost = Math.ceil((weight - BASE_WEIGHT)/EXTRA_OUNCES ) * ADDED_AMOUNT; // calc number of 4 over 16


        // calc the totalCost

        totalCost = baseCost + addedCost;
    } // end computeCost method





} // end shipping class
