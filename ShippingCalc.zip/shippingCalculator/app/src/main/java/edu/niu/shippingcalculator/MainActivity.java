package edu.niu.shippingcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    //Data Members Vars

    private ShippingItem item;
    private EditText weightET;
    private TextView baseTV, addedTv, totalTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       // connect the Edit and text ciews to items on  screen

        weightET = findViewById(R.id.weightEditText);

        baseTV = findViewById(R.id.baseCostTextView);
        addedTv = findViewById(R.id.addedCostTextView);
        totalTV = findViewById(R.id.totalCostTextView);

        // creatte the shipping item
        item = new ShippingItem();

        //Place the app's inintal focus on EditText
        weightET.requestFocus();

        // attach the TextWatcher to EDit Tecit
        weightET.addTextChangedListener( weightWatcher ); // changed the name to ww




    }// end OnCreate

    // go otuside oncreate and build named texteatcher
    public TextWatcher weightWatcher  = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override // only we we fuck with
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            // try to change the weight for the item being shipped
            try
            {
                // set the wight for Shipping item
                item.setWeight(Integer.parseInt(s.toString())); // string to int converter

            }
            catch(NumberFormatException nfe ) // name it if you want
            {
               // if bad data, set weight to 0
                item.setWeight(0);

            }

            // Format and display the costs
            DecimalFormat df = new DecimalFormat( "#0.00");


            baseTV.setText( "$" + df.format(item.getBaseCost()));
            addedTv.setText("$" + df.format(item.getAddedCost()));
            totalTV.setText("$" + df.format(item.getTotalCost()));

        }// end OnTechChange


        @Override
        public void afterTextChanged(Editable s) {

        }
    }; // dont forget to add semi colon

} // end main
