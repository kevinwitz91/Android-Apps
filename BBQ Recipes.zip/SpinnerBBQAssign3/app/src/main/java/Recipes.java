import KevinWitz.cs.niu.edu.R;

public class Recipes {

    public static int[] picIds = {R.drawable.ribs, R.drawable.turkey,
            R.drawable.brisket, R.drawable.steak, R.drawable.chicken };
}
