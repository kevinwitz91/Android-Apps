package KevinWitz.cs.niu.edu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;

public class RecipeInfoActivity extends AppCompatActivity {

    //global variabless

    TextView recipeView, recipeInformation;

    String recipeName;
    String recipeDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_info);


        recipeView = findViewById(R.id.recipeTextView);
        recipeInformation = findViewById(R.id.descriptionTextView);

        // make scrollable if need be
        recipeInformation.setMovementMethod(new ScrollingMovementMethod());




        //intent to push from first intent
        Intent info = getIntent();
        recipeName = info.getStringExtra("food");
        Intent des = getIntent();
        recipeDescription = des.getStringExtra("des");

        //setting info into text
        recipeView.setText(recipeName);
        recipeInformation.setText(recipeDescription);

    }// end oncreate

    public void goHome(View view){
        finish();
    }
}//end main
