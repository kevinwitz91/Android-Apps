package KevinWitz.cs.niu.edu;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    // variables
    String record, info;
    private Spinner BBQSpinner;

    ImageView IVBBQPicture;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect the spinner to the gui
        BBQSpinner = findViewById(R.id.spinner);
        IVBBQPicture = findViewById(R.id.imageView);


        // create a spinner list
        List<String> values = new ArrayList<>();

        //put values into the spinner
        values.add("Ribs");
        values.add("Turkey");
        values.add("Brisket");
        values.add("Steak");
        values.add("Chicken");



        //Create a layout adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,R.layout.spinner_view,values);


        //populate the spinner now
        BBQSpinner.setAdapter(adapter);


        // spinner case statement for foods to be chosen
        BBQSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 0:
                        record = "Ribs";
                        IVBBQPicture.setImageResource(R.drawable.ribs);
                        info = "Prepare smoker for indirect cooking at 250⁰ add cherry and hickory wood for smoke flavor.\n" +
                                "Remove the end bones from each slab of ribs to give a square appearance. Trim any excess cartilage from the top of each slab. Pull the membrane off and remove excess fat & sinew from top and bottom of each.\n" +
                                "Apply thin coat of mustard to each side. Layer the Killer Hogs Hot BBQ Rub on both sides followed by a light dusting of Killer Hogs The BBQ Rub.\n" +
                                "Place the ribs on the smoker and cook for 2 hours. Spritz with a 50:50 mixture of Apple Juice & Water every 30 minutes.\n" +
                                "Place a sheet of aluminum foil on the counter big enough to wrap the ribs. Layer half the margarine, brown sugar, and honey on the foil. Place a slab of ribs meat side down into the mixture and drizzle ¼ cup of Killer Hogs Vinegar Sauce on the back side. Close the foil and repeat for the other slab. Now DONE!\n" ;
                        break;
                    case 1:
                        record = "Turkey";
                        IVBBQPicture.setImageResource(R.drawable.turkey);
                        info = "Thaw frozen turkey in refrigerator for 5 days; check cavity for neck/organs (discard or save for making stock).\n" +
                                "Place turkey in an XXL Ziplock bag and pour brine* over bird. Store in a cooler with ice around the bag to keep cool. Brine Turkey for 24 hours replacing ice as necessary.\n" +
                                "Prepare smoker for indirect cooking at 300⁰ using pecan wood for smoke flavor.\n" +
                                "Remove turkey from brine and rinse under cool water. Pat skin dry with paper towel.\n" +
                                "Place quartered apples and onion in the cavity and tie the legs together with butcher twine. Inject the breast, legs, and thighs with Cajun injection*. Coat the skin with vegetable cooking spray.\n" +
                                "Season the outside of the turkey with Cajun seasoning* and place on preheated smoker.\n" +
                                "Smoke the turkey for 3 ½ hours spraying the skin with additional cooking spray as necessary. Remove the turkey from the smoker when internal temperature reaches 165⁰ in the breast and 175⁰ in the thigh.\n" +
                                "Cover turkey loosely in aluminum foil and rest for 20 minutes. Carve into desired portions and serve. ";
                        break;
                    case 2:
                        record = "Brisket";
                        IVBBQPicture.setImageResource(R.drawable.brisket);
                        info = "Prepare offset Bbq pit for indirect cooking at 275 degrees using splits of Pecan wood for fuel. (Any style pit can be substituted just maintain 275 degrees)\n" +
                                "Remove brisket from cryovac packaging and blot excess moisture with paper towel. Trim excess fat to 1/4”. Remove sinew (silver skin) from flat and any discolored meat around the edges.\n" +
                                "Combine Kosher Salt and Black Pepper and liberally coat all sides of the brisket then add a light layer of Killer Hogs Hot Rub.\n" +
                                "Place the brisket fat side down on the Bbq pit and smoke until the outside begins to turn dark (about 170 degrees internal).\n" +
                                "Wrap the brisket in pink butchers paper and insert a probe thermometer into the thickest portion of the flat.\n" +
                                "Place the brisket back on the pit and continue to cook until internal temperature reaches 202-204 degrees.\n" +
                                "Rest the brisket in a dry cooler for a minimum of 1 hour before slicing. ";
                        break;
                    case 3:
                        record = "Steak";
                        IVBBQPicture.setImageResource(R.drawable.steak);
                        info = " Prepare Charcoal or Gas Grill for direct heat. Grate temperature of 500⁰.\n" +
                                "Remove excess fat from sides of each ribeye along with any silver skin on the edges.\n" +
                                "Season each side with Killer Hogs AP Rub and rest in a cooler for 30 minutes, then layer on Killer Hogs Steak Rub, and a light coat of Killer Hogs Hot Rub.\n" +
                                "Place each ribeye on grill grate and set timer for 2 minutes.\n" +
                                "Twist each ribeye 90⁰ and grill additional 2 minutes.\n" +
                                "Turn ribeyes over and set timer for 1 minute 45 seconds.\n" +
                                "Baste with melted butter mixed with ½ teaspoon AP Rub, turn each steak 90⁰, and remove from grill when internal temperature reaches 128-130⁰ on instant read thermometer. Total cook time is approximately 8 minutes.\n" +
                                "Rest ribeyes for 5-7 minutes before turning into judges.";
                        break;
                    case 4:
                        record = "Chicken";
                        IVBBQPicture.setImageResource(R.drawable.chicken);
                        info = "Prepare offset smoker or any BBQ Grill for indirect cooking at 275 degrees using your favorite wood for smoke flavor (I used Post Oak for this recipe)\n" +
                                "Season the outside of each piece of chicken with the Chicken Rub - substitute your favorite rub if you like\n" +
                                "Place the chicken on the smoker and cook until the internal temperature in the breast reach 155 degrees. Turning and basting with the BBQ Chicken Mop* every 30 minutes.\n" +
                                "Pour the BBQ Sauces into a small aluminum pan and place on the smoker to warm. Once the internal temperature in the breast hit 165 start brushing the sauce on both sides and continue flipping the chicken every 15-30 minutes until the sauce caramelizes on the outside and the internal temperature reach a minimum of 165 in the white meat and 175 in the dark.\n" +
                                "Remove the BBQ Chicken from the smoker and serve. ";

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    } // End OnCreate

    //Button to go to recipe info
    //uses the intents to get info into second screen
    public void showRecipe(View view){
        Intent recipeIntent = new Intent(MainActivity.this, RecipeInfoActivity.class);
        recipeIntent.putExtra("food", record);
        recipeIntent.putExtra("des", info);
        startActivity(recipeIntent);

    }
} // End MainActivity
