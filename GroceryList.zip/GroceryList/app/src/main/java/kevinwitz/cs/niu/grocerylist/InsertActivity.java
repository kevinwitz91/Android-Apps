package kevinwitz.cs.niu.grocerylist;
/********************************************************************
 CSCI 322 - Assignment 5 - Semester (Spring) 2020

 Progammer: Kevin
 Section:   1
 TA:        Andrew
 Date Due:  May 1, 2020

 Purpose:   Create a db that acts like a grocery list

 *********************************************************************/

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class InsertActivity extends AppCompatActivity
{

    private DatabaseManager databaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        //create the db
        databaseManager = new DatabaseManager(this);
    }// end onCreate

    // methods
    public void goBack(View view)
    {
        finish();

    }// end goBack







    public void addItem(View view)
    {
        //create edit text for grocery
        EditText itemNameET = findViewById(R.id.itemNameEditText);
        TextView itemListET = findViewById(R.id.itemsTextView);


        ///
        //Build string to display info
        String dataBaseString;
        databaseManager = new DatabaseManager(this);

        //get an initial val
        dataBaseString = "\n\n";

        //array list to hold db info
        ArrayList<GroceryItem> groceries = databaseManager.selectAll();

        //foreachloop through array to get each name of food and add to string
        for(GroceryItem groceryItem : groceries)
        {
            dataBaseString += groceryItem.groceryToString() + "\n";

        }
        TextView databaseTV = findViewById(R.id.itemsTextView);
        itemListET.setText(dataBaseString);



        ///



        //get the data from the edit text field
        String itemName = itemNameET.getText().toString();

        // candy object
        GroceryItem newItem = new GroceryItem(0, itemName);

        //insert the item in
        databaseManager.insertGrocery(newItem);

        //clear the edit text after they click add
        itemNameET.setText("");
       // itemListET.setText(itemName);


    }// end addItem




}// end InsertActivity
