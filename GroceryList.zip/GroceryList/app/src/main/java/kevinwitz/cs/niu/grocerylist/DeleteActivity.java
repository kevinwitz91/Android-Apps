package kevinwitz.cs.niu.grocerylist;
/********************************************************************
 CSCI 322 - Assignment 5 - Semester (Spring) 2020

 Progammer: Kevin
 Section:   1
 TA:        Andrew
 Date Due:  May 1, 2020

 Purpose:   Create a db that acts like a grocery list

 *********************************************************************/
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Toast;


import java.util.ArrayList;

public class DeleteActivity extends AppCompatActivity
{
    //create db manager
    private DatabaseManager databaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        databaseManager = new DatabaseManager(this);

        updateView();


    }// end onCreate

    public void updateView()
    {
        //array list that has all info
        ArrayList<GroceryItem> groceries = databaseManager.selectAll();

        //layout to hold info
        RelativeLayout layout = new RelativeLayout(this);
        ScrollView scrollView = new ScrollView(this);
        RadioGroup group = new RadioGroup(this);

        //get all the info from ArrayList and put inside radio buttons
        for(GroceryItem groceryItem : groceries)
        {
            //crea
            RadioButton radioButton = new RadioButton(this);

            //set the Id and text for checkbox
            radioButton.setId(groceryItem.getId());
            radioButton.setText(groceryItem.groceryToString());

            //add the checkbox to the group
            group.addView(radioButton);
        }

        //event handeling
        RadioButtonHandler handler = new  RadioButtonHandler();
        group.setOnCheckedChangeListener(handler);

        //add the radio to the scrollview
        scrollView.addView(group);

        //add the scrollview to the rel view
        layout.addView(scrollView);

        //add a back button the layout
        Button backButton = new Button(this);
        backButton.setText("Back");
        backButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });


        //set up parameters to the place scrree
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                  ViewGroup.LayoutParams.WRAP_CONTENT );

        //make sure at bottom
        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        params.addRule(RelativeLayout.CENTER_HORIZONTAL);
        params.setMargins(0,0,0,50);


        //add the back back button to rel layout
        layout.addView(backButton, params);

        //display the rel layout
        setContentView(layout);

    }// end updateView

    //create InnerClass to handle the button and clicks
    private class RadioButtonHandler implements RadioGroup.OnCheckedChangeListener
    {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId)
        {
            //delete info from the db
            databaseManager.deleteByID(checkedId);
            Toast.makeText(DeleteActivity.this, "Item was deleted",Toast.LENGTH_SHORT).show();

            //update the display
            updateView();

        }// end onCheckChanged
    }// End CheckBOxBUtton Handler class
}//end delete activity

















