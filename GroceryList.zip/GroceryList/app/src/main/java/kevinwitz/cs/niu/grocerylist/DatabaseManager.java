package kevinwitz.cs.niu.grocerylist;
/********************************************************************
 CSCI 322 - Assignment 5 - Semester (Spring) 2020

 Progammer: Kevin
 Section:   1
 TA:        Andrew
 Date Due:  May 1, 2020

 Purpose:   Create a db that acts like a grocery list

 *********************************************************************/

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DatabaseManager extends SQLiteOpenHelper
{

    private static final String DATABASE_NAME = "GroceryDB",
            TABLE_NAME = "Grocery",
            ITEM_ID = "id",
            ITEM_NAME = "name";

    private static final int DATABASE_VERSION = 1; // in case of corruption


    public DatabaseManager(@Nullable Context context)
    {
        super(context, DATABASE_NAME,null,DATABASE_VERSION);
    }// end constructor

    //create db inside here
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        //sql statement to create the db
        String sqlCreate = "create table " + TABLE_NAME + "( " +
                            ITEM_ID + " integer primary key autoincrement, " +
                            ITEM_NAME + " text )";

        //create the db
        db.execSQL(sqlCreate);
    }// end onCreate

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        //string to drop table if it exists
        String sqlDrop = "drop table if exists " + TABLE_NAME;

        //drop the table now
        db.execSQL(sqlDrop);

        //recreate the db now
        onCreate(db);

    }// end onUpgrade

    //Method to insert into db
    public void insertGrocery(GroceryItem groceryItem) //this object may need help
    {
        //sql command
        String sqlInsert = "insert into " + TABLE_NAME +
                            " values( null, '" + groceryItem.getName() +
                            "' )";
        //get the db
        SQLiteDatabase database = getWritableDatabase();

        //insert into the db
        database.execSQL(sqlInsert);

        //close db now
        database.close();

    }// end insertGrocery

    // method to see info in
    public ArrayList<GroceryItem> selectAll()
    {
        //SQL select command
        String sqlSelect = "select * from " + TABLE_NAME;

        //get the db
        SQLiteDatabase database = getWritableDatabase();

        //get the info from the db
        Cursor cursor = database.rawQuery(sqlSelect, null);

        //array list to hold grocery
        ArrayList<GroceryItem> groceries = new ArrayList<>();

        //divide up the cursor into the individual objects
        while(cursor.moveToNext())
        {
            //divide the db items into its 3 parts
            Integer currentID = cursor.getInt(0);
            String currentName = cursor.getString(1);

            //create a candy object
            GroceryItem groceryItem = new GroceryItem(currentID, currentName);

            //add the grocery to array list
            groceries.add(groceryItem);

        }//end while loop

        return groceries;
    }// end select all

    //Method to delete an item from db
    public  void deleteByID(int id)
    {
        //sql command string for delete
        String sqlDelete = "delete from " + TABLE_NAME + " where " +
                            ITEM_ID + " = " + id;

        //get the db

        SQLiteDatabase database = getWritableDatabase();

        //delete the item from the db
        database.execSQL(sqlDelete);

        //close the db
        database.close();

    }// end deleteID

public void updateById(int id, String name)
{
    //Sql command first and set up as string
    String sqlUpdate = "update " + TABLE_NAME + " set " +
            ITEM_NAME + " = '" + name + "'" +
            " where " + ITEM_ID + " = " + id;
    SQLiteDatabase database = getWritableDatabase();
    database.execSQL(sqlUpdate);
    database.close();


}//end update












}// end db manager