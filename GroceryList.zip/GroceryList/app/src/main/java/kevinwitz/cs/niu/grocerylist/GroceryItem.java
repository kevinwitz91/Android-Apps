package kevinwitz.cs.niu.grocerylist;
/********************************************************************
 CSCI 322 - Assignment 5 - Semester (Spring) 2020

 Progammer: Kevin
 Section:   1
 TA:        Andrew
 Date Due:  May 1, 2020

 Purpose:   Create a db that acts like a grocery list

 *********************************************************************/
public class GroceryItem
{
    private int id;
    private String name;

    public GroceryItem(int newId, String newName)
    {
        setId(newId);
        setName(newName);
    }// end constructor

    //getters
    public int getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    //Setters
    public void setId( int newId )
    {
        id = newId;
    }

    public void setName( String newName )
    {
        name = newName;
    }




    //Method to make display Grocery Item nicer
    public String groceryToString()
    {
        return name + " ";
    }



}// end GroceryItem
