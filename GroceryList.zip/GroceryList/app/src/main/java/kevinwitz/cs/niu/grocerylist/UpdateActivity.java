package kevinwitz.cs.niu.grocerylist;
/********************************************************************
 CSCI 322 - Assignment 5 - Semester (Spring) 2020

 Progammer: Kevin
 Section:   1
 TA:        Andrew
 Date Due:  May 1, 2020

 Purpose:   Create a db that acts like a grocery list

 *********************************************************************/
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Point;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class UpdateActivity extends AppCompatActivity
{
    private DatabaseManager databaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        databaseManager = new DatabaseManager(this);

        updateView();
    }// and onCreate

    public void updateView()
    {
        //Get an array list to hold info from db
        ArrayList<GroceryItem> groceryItems = databaseManager.selectAll();

        //if there is info in the db
        if( groceryItems.size() > 0)
        {
            ScrollView scrollView = new ScrollView(this);

            //grid to hold info
            GridLayout gridLayout = new GridLayout(this);

            //set up rows and collums for the grid
            gridLayout.setRowCount(groceryItems.size() + 1);
            gridLayout.setColumnCount(2);

            //create a button handler for update
            ButtonHandler buttonHandler = new ButtonHandler();

            //find the width of the screen
            Point point = new Point();
            getWindowManager().getDefaultDisplay().getSize(point);

            int width = point.x;

            //prcoess all the groceries in array list
            for(GroceryItem groceryItem : groceryItems)
            {
                //format the id for the grocery
                EditText name = new EditText(this);
                name.setText(groceryItem.getName());
                name.setId(10 * groceryItem.getId());

                //update the button
                Button updateButton = new Button(this);
                updateButton.setText("Update");
                updateButton.setId(groceryItem.getId());
                updateButton.setOnClickListener(buttonHandler);

                //add them to grid layout now
                gridLayout.addView(name,(int) (width * .50), ViewGroup.LayoutParams.WRAP_CONTENT);
                gridLayout.addView(updateButton, (int) (width * .50), ViewGroup.LayoutParams.WRAP_CONTENT);

            }// end for each


            Button backButton = new Button(this);
            backButton.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    finish();
                }
            });


            GridLayout.Spec rowSpec = GridLayout.spec(groceryItems.size(), 1),
                                    colSpec = GridLayout.spec(0,2);

            GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams(rowSpec,colSpec);

             //Apply the parameters to the button
            backButton.setLayoutParams(layoutParams);
            backButton.setWidth(width);
            backButton.setHeight((int)(width * .10));

            backButton.setGravity(Gravity.CENTER);
            backButton.setText("Back");

            // add back button to gridlaout
            gridLayout.addView(backButton);

            //add the grid to scroll view
            scrollView.addView(gridLayout);

            setContentView(scrollView);




        }// end if


    }// end updateView

    //custom button handler
    private class ButtonHandler implements View.OnClickListener
    {
        @Override
        public void onClick(View v)
        {
            //grocery id will be associated with the update button
            int groceryID = v.getId();

            //deittext fields for name
            EditText nameET = findViewById(10 * groceryID);

            //get the info from edit text fields
            String name = nameET.getText().toString();

            databaseManager.updateById(groceryID, name);
            Toast.makeText(UpdateActivity.this,"Update success", Toast.LENGTH_SHORT).show();
            updateView();



        }//end onclick
    }// end ButtonHandler


}// end UpdateActivity
