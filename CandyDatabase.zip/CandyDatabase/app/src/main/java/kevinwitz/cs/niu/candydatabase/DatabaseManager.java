package kevinwitz.cs.niu.candydatabase;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DatabaseManager extends SQLiteOpenHelper
{
    private static final String DATABASE_NAME = "candyDB",
                                TABLE_NAME = "candy",
                                ITEM_ID = "id",
                                ITEM_NAME = "name",
                                ITEM_PRICE = "price";

    private static final int DATABASE_VERSION = 1;

    public DatabaseManager(@Nullable Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }//end constuctor

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        //sql statement to create the database

        String sqlCreate = "create table " + TABLE_NAME + "( " +
                            ITEM_ID + " integer primary key autoincrement, " +
                            ITEM_NAME + " text, " +
                            ITEM_PRICE + " real )";

        //create the database now
        db.execSQL(sqlCreate);

    }// end onCreate

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
     //string to drop old database if table exists
     String sqlDrop = "drop table if exists " + TABLE_NAME;

     //drop the table
        db.execSQL(sqlDrop);

        //re create the db
        onCreate(db);

    }// end onUpgrade

    //method to do insertion into db
    public void insertCandy( Candy candy)
    {
        //create string to insert SQl commander
        String sqlInsert = "insert into " + TABLE_NAME +
                            " values( null, '" + candy.getName() +
                            "', '" + candy.getPrice() + "' )";

        //get the database
        SQLiteDatabase database = getWritableDatabase();

        // insert the candy tino db
        database.execSQL(sqlInsert);

        //close the db now
        database.close();
    }//end insertCandy



    //method to retreive all the info in db
    public ArrayList<Candy> selectAll ()
    {
        //create a string wuth sql command (select command)

        String sqlSelect = "select * from " + TABLE_NAME;

        //get the db
        SQLiteDatabase database = getWritableDatabase();

        //get the info from db
        Cursor cursor = database.rawQuery(sqlSelect, null);

        //create an arraylist to hold info for candy
        ArrayList<Candy> candies = new ArrayList<>();

        //divide cursor to individual candies
        //process all data entered to db
        while(cursor.moveToNext())
        {
            //divide the db items into its 3 parts
            Integer currentID =  cursor.getInt(0);

            String currentName = cursor.getString(1);

            Double currentPrice = cursor.getDouble(2);

            //now create a candy object
            Candy candy = new Candy(currentID, currentName, currentPrice);

            //add it to array list now
            candies.add(candy);




        }// end while
        return candies;


    }// end select All


    //Method to delete an item from db
    public void  deleteByID(int id)
    {
        //sql delete command
        String sqlDelete = "delete from " + TABLE_NAME + " where " + ITEM_ID
                            + " = " + id;

        //get the db
        SQLiteDatabase database = getWritableDatabase();

        //delete an item from db
        database.execSQL(sqlDelete);

        //close the db
        database.close();
        
    }// edn deletebyID


    public void updateByID(int id, String name, double price)
    {
        //sql command first to update
        String sqlUpdate = "update " + TABLE_NAME + " set " +
                            ITEM_NAME + " = '" + name + "', " +
                            ITEM_PRICE + " = '" + price + "' " + //check ehre
                            " where " + ITEM_ID + " = " + id;
        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sqlUpdate);
        database.close();

    }//end update














}//ends DatabaseManger class
