package kevinwitz.cs.niu.candydatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Point;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class UpdateActivity extends AppCompatActivity
{
    private DatabaseManager databaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        databaseManager = new DatabaseManager(this);

        updateView();



    }//end onCreate


    public void updateView()
    {
        // Get info from the db
        ArrayList<Candy> candies = databaseManager.selectAll();

        //if there is info in the db
        if(candies.size() > 0)
        {
            ScrollView scrollView = new ScrollView(this);
            GridLayout gridLayout = new GridLayout(this);

            //set up rows and collums for the grid
            gridLayout.setRowCount(candies.size()+ 1);
            gridLayout.setColumnCount(4); // id number/ name/ price/ updte

            //button handler
            ButtonHandler buttonHandler = new ButtonHandler();

            //find the width of screen using point object
            Point point = new Point();
            getWindowManager().getDefaultDisplay().getSize(point);
            int width = point.x;

            //process all the candies in the array list
            for(Candy candy : candies)
            {
                //creating layout of the screen
                //format the ID number for new
                TextView idTV = new TextView(this);
                idTV.setGravity(Gravity.CENTER);
                idTV.setText("" + candy.getId());

                //format the name and get onto screen
                EditText name = new EditText(this);
                name.setText(candy.getName());

                name.setId(10 * candy.getId());

                //foramt the price
                EditText price = new EditText(this);
                price.setText("" + candy.getPrice());
                price.setId(10 * candy.getId() + 1);
                price.setInputType(InputType.TYPE_NUMBER_FLAG_DECIMAL);

                //update button
                Button updateButton = new Button(this);
                updateButton.setText(R.string.update_button_label);
                updateButton.setId(candy.getId());
                updateButton.setOnClickListener(buttonHandler);

                //add the 4 objects to the grid
                gridLayout.addView(idTV,(int)(width * .10), ViewGroup.LayoutParams.WRAP_CONTENT);
                gridLayout.addView(name, (int)(width * .40), ViewGroup.LayoutParams.WRAP_CONTENT);
                gridLayout.addView(price, (int)(width * .15), ViewGroup.LayoutParams.WRAP_CONTENT);
                gridLayout.addView(updateButton, (int)(width * .35), ViewGroup.LayoutParams.WRAP_CONTENT);
            }// end for

            //Back Button
            Button backButton = new Button(this);
            backButton.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    finish();// just going back to main
                }
            });

            GridLayout.Spec rowsSpec = GridLayout.spec(candies.size(), 1),
                    colSpec = GridLayout.spec(0,4);


            GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams(rowsSpec,colSpec);

            //apply
            backButton.setLayoutParams(layoutParams);

            backButton.setWidth(width);
            backButton.setHeight((int)(width * .10));

            backButton.setGravity(Gravity.CENTER);
            backButton.setText(R.string.back_button_label);

            //add the back button to the grid
            gridLayout.addView(backButton);

            // add the grid layout to scroll view
            scrollView.addView(gridLayout);

            //display the layout
            setContentView(scrollView);
        }// end if

    }//end updateView


    //custom button handler
    private class ButtonHandler implements View.OnClickListener
    {
        @Override
        public void onClick(View v)
        {
            //candy id will be asso
            int candyID = v.getId();

            //editTex for name and price
            EditText nameET =  findViewById(10 * candyID),
                    priceET = findViewById(10 * candyID +1);

            //get the info from the ET fields
            String name = nameET.getText().toString(),
                    pricestr = priceET.getText().toString();

            try
            {
                //get the numerical version of price
                double price = Double.parseDouble(pricestr);

                //update database
                databaseManager.updateByID(candyID, name,price);

                updateView();// autoupdates for me

            }
            catch (NumberFormatException nfe)
            {
                Toast.makeText(UpdateActivity.this,"Update price error",Toast.LENGTH_SHORT).show();
            }


        }
    }// end Button handler class


}// end UpdateActivity
