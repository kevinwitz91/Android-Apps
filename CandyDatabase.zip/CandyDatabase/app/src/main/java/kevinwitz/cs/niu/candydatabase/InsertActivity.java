package kevinwitz.cs.niu.candydatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class InsertActivity extends AppCompatActivity
{

    //db manger object
    private DatabaseManager databaseManager;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        //crate the db
        databaseManager = new DatabaseManager(this);

    }//end onCreate

    //Methods for to handle the on click

    public void goBack(View view)
    {
        finish(); // go back to main activ
    }// end goBack

    public void addItem(View view)
    {
        //connect to the editText fields on screen
        EditText itemNameET = findViewById(R.id.itemNameEditText),
                itemPriceET = findViewById(R.id.itemPriceEditText);

        //get the data now from the edittets

        String itemName = itemNameET.getText().toString(),
                itemPrice = itemPriceET.getText().toString();


        try
        {
            //convert string to numerical value
            double price = Double.parseDouble(itemPrice);

            //create candy objects thats being insterted into db
            Candy newItem = new Candy(0, itemName, price);

            // Now insert it into the db

            databaseManager.insertCandy(newItem);
        }
        catch ( NumberFormatException nfe)
        {
            Toast.makeText(this, "Price  Error", Toast.LENGTH_SHORT).show();
        }

        //clear the edit texts fields in case user wants toa dd more data
        itemNameET.setText("");
        itemPriceET.setText("");

        //make sure that curser goes back to namefield aka set focus
        itemNameET.requestFocus();



    }// end addItem





}//End InsertActivity



