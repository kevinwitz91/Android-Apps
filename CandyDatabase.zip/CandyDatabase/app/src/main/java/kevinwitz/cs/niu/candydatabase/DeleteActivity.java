package kevinwitz.cs.niu.candydatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import java.util.ArrayList;

public class DeleteActivity extends AppCompatActivity
{

    //create Db manager
    private DatabaseManager databaseManager;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        databaseManager = new DatabaseManager(this);

        updateView();

    }//end onCreate

    public void updateView()
    {
        //array list that has all the info in db
        ArrayList<Candy> candies = databaseManager.selectAll(); // fillng with select all

        //layout
        RelativeLayout layout = new RelativeLayout(this);

        //in case theres alot of info
        ScrollView scrollView = new ScrollView(this);
        // this is so we can have more than1 view
        RadioGroup group = new RadioGroup(this);

        //Get info from Array List and put into radio buttons
        for(Candy candy : candies)
        {
            //create RadioButton
            RadioButton radioButton = new RadioButton(this);

            //set the ID and text for RadioButton
            radioButton.setId(candy.getId());
            radioButton.setText(candy.candyToString()); //displays all info

            //add the radio button to the group
            group.addView(radioButton);
        }


        //event handeling
        RadioButtonHandler handler = new RadioButtonHandler();
        group.setOnCheckedChangeListener(handler);

        //add the radiogroup the scrollview
        scrollView.addView(group);

        //add the scrollview to the relative layour
        layout.addView(scrollView);


        //add a back button to the layout
        Button backButton = new Button(this);
        backButton.setText(R.string.back_button_label);
        backButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();// going back to main
            }
        });

        //set up parameters to place the back bottom of scrren
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                                                                            ViewGroup.LayoutParams.WRAP_CONTENT);

        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);//set on bottom
        params.addRule((RelativeLayout.CENTER_HORIZONTAL));//center on bottom
        params.setMargins(0,0,0,50);//little margin from bottom


        //add backbutton to rel layout
        layout.addView(backButton,params);

        //display the relative layout
        setContentView(layout);




    }// end updateView

    //create inner class to handle button clicks and buttons
    private class RadioButtonHandler implements RadioGroup.OnCheckedChangeListener
    {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId)
        {
            //delete info from the database
            databaseManager.deleteByID(checkedId);

            Toast.makeText(DeleteActivity.this, "Candy was deleted",Toast.LENGTH_SHORT).show();

            //update the display
            updateView();
        }//end oncheckedChanged
    }//end RadioButtonhandler

}// end DeleteActivity









