package kevinwitz.cs.niu.exampart2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

//***************************************************************************
//
//
//  CSCI 322 Which number is greater Act.
//
//  Created by Kevin Witz
//
//***************************************************************************

public class Activity2 extends AppCompatActivity {

    // variables
    EditText ET1, ET2;

    int result;

    TextView TVResults;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        ET1 = findViewById(R.id.numberOneEditText);
        ET2 = findViewById(R.id.numberTwoEditText);
        TVResults = findViewById(R.id.resultsTextView);


    }// end oncreate

    // calc fucntion to do little math and get larger number

    public void goCalc(View view) {
        // if the fileds are empty give toast message.
        if (ET1.getText().toString().matches("") || ET2.getText().toString().matches("")) {
            Toast.makeText(view.getContext(), "You must input numbers", Toast.LENGTH_LONG).show();
            return;
        }

        int a = Integer.parseInt(ET1.getText().toString());
        int b = Integer.parseInt(ET2.getText().toString());

        if (a > b)
            TVResults.setText("Larger number is: " + a);

         if(b>a) {
            TVResults.setText("larger number is: " + b);
        }
        if (a == b) {
            TVResults.setText("The numbers are the same!!");
        }




    }


    public void goHome(View view){

        //take me home
        Intent homeIntent = new Intent(Activity2.this, MainActivity.class);
        //exiting this activity
        finish();
    }
}// end main
