package kevinwitz.cs.niu.exampart2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
//***************************************************************************
//
//
//  CSCI 322 Is the numbers divisble by ???? act.
//
//  Created by Kevin Witz
//
//***************************************************************************
public class DivisableActivity extends AppCompatActivity {

    EditText ETNum1, ETNum2;
    int result;

    TextView TVResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_divisable);

        ETNum1 = findViewById(R.id.numberOneEditText);
        ETNum2 = findViewById(R.id.numberTwoEditText);

        TVResults = findViewById(R.id.answerTextView);
    }

    public void goHome(View view){

        Intent homeIntent = new Intent(DivisableActivity.this, MainActivity.class);
        // homeIntent.putExtra("result", result);
        // ((Activity)view.getContext()).setResult(RESULT_OK, homeIntent);
        //exiting this activity
        finish();

    }

    public void goCalc(View view){

        //if the fields are empty
        if(ETNum1.getText().toString().matches("")||(ETNum2.getText().toString().matches("")))
        {
            Toast.makeText(view.getContext(),"Field Cannot be Empty", Toast.LENGTH_LONG).show();
            return;
        }

        int a = Integer.parseInt(ETNum1.getText().toString());
        int b = Integer.parseInt(ETNum2.getText().toString());

        if(a % b ==0){
            TVResults.setText("The number is divisible");
        }
        else{
            TVResults.setText("The number is NOT divisible");
        }



    }

}
