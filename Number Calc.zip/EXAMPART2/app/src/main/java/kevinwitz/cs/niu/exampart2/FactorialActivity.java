package kevinwitz.cs.niu.exampart2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

//***************************************************************************
//
//
//  CSCI 322 Getting the Factorial
//
//  Created by Kevin Witz
//
//***************************************************************************

public class FactorialActivity extends AppCompatActivity {

    EditText ETFactorial;
    Integer result;
    TextView TVResultFact;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_factorial);

        TVResultFact = findViewById(R.id.resultsTextView);
        ETFactorial = findViewById(R.id.numberOneEditText);
    }

    // do the math
    public void goCalc(View view) {

        if (ETFactorial.getText().toString().matches("")) {
            Toast.makeText(view.getContext(), "Field Cannot be Empty", Toast.LENGTH_LONG).show();
            return;
        }
        //if the fields are empty

        int a = Integer.parseInt(ETFactorial.getText().toString());
        int k =1;
         for(int i=1; i<=a; i++){
             k=k*i;
             TVResultFact.setText(Integer.toString(k));
         }

    }







    public void goHome(View view){
        Intent homeI = new Intent(FactorialActivity.this, MainActivity.class);
       // homeIntent.putExtra("result", result);
      //  homeIntent.putExtra("result",result);
      //  setResult(RESULT_OK, homeIntent);
       // ((Activity)view.getContext()).setResult(RESULT_OK, homeI);
        //exiting this activity
        finish();

    }
}
