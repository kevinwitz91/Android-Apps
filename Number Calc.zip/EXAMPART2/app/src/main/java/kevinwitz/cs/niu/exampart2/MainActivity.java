package kevinwitz.cs.niu.exampart2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    boolean larger = false,
            divisable = false,
            factorial = false;

    int REQUEST_CODE = 1;
    public static final int RESULT_OK = -1;

    int numberResult;

    //Button cal;

    RadioGroup radioChoies;
    TextView TVResults;
    String results = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // connecting to the gui
        radioChoies = findViewById(R.id.operationRadioGroup);
       // TVResults = findViewById(R.id.resultTextView);



        // checking to see which radio button the user chose
        radioChoies.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                if(R.id.largerRadioButton == checkedId){
                    larger = true;
                }
                else if(R.id.divisibleRadioButton == checkedId){
                    divisable = true;
                }
                else if(R.id.factorialRadioButton == checkedId){
                    factorial = true;
                }

            }// end onCheckedChaned
        }); // end set on cheked chaned listener


    } // end onCreate



    // the onClick button for the 3 radio options
    public void doOperation(View view)
    {
        if(larger){
            Intent largerIntent = new Intent(MainActivity.this, Activity2.class);
            startActivityForResult(largerIntent, REQUEST_CODE);
            larger = false;
        }

        else if(divisable){
            Intent divIntent = new Intent(MainActivity.this, DivisableActivity.class);
            startActivityForResult(divIntent, REQUEST_CODE);
            divisable = false;
        }

        else if(factorial){
            Intent factIntent = new Intent(MainActivity.this, FactorialActivity.class);
            startActivityForResult(factIntent, REQUEST_CODE);
            factorial = false;
        }

        else
        {
            Toast.makeText(view.getContext(), "You need to select an option, cannont be blank ",
                                                    Toast.LENGTH_LONG).show();
            return;
        }



    }

    // method to get data back



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_CODE && resultCode == RESULT_OK)
        {
            numberResult = data.getIntExtra("result", REQUEST_CODE);
          // TVResults.setText(String.format("%.4f",numberResult));
            TVResults.setText(numberResult);



        }

    }
}
// end Main

