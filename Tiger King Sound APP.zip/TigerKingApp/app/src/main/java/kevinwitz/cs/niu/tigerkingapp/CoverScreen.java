package kevinwitz.cs.niu.tigerkingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class CoverScreen extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cover_screen);

        //create a TimerTask object
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                //finish execution of splash
                finish();

                //start the MainActivity
                Intent mainIntent = new Intent(CoverScreen.this, MainActivity.class);

                startActivity(mainIntent);
            }
        };

        //create a timer object
        Timer opening = new Timer();

        //schedule the task and the amount of time to pause
        opening.schedule(task,5000);
    }// end onCreate
}// end Main
