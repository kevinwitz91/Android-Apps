package kevinwitz.cs.niu.tigerkingapp;
/********************************************************************
        CSCI 322 - Assignment 4 - Semester (Spring) Year 2020

        Progammer: Kevin Witz
        Section:   1
        TA:        Andrew
        Date Due:  April 15, 2020

        Purpose:   The application should have the ability to play
                    1 of (at least) 6 sounds when the user clicks on a
                    button.
        *********************************************************************/

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{

    // all buttons
    private Button joeBtn, carrelBtn, docBtn, erikBtn, jeffBtn, johnBtn;

    // all media player
    private MediaPlayer joeMedia,caroleMedia, docMedia, jeffMedia, erikMedia, johnMedia;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // connecting to the gui
        joeBtn = findViewById(R.id.joeButton);
        jeffBtn = findViewById(R.id.jeffButton);
        carrelBtn = findViewById(R.id.carrelButton);
        docBtn = findViewById(R.id.docButton);
        erikBtn = findViewById(R.id.erikButton);
        johnBtn = findViewById(R.id.johnButton);

        //create the media players objects
        joeMedia = new MediaPlayer();
        joeMedia = MediaPlayer.create(this, R.raw.joemp3);

        //looping the sound clip so its keeps playing longer
        joeMedia.setLooping(true);


        //create the media players objects
        caroleMedia = new MediaPlayer();
        caroleMedia = MediaPlayer.create(this, R.raw.carrolbaskin);

        //looping the sound clip so its keeps playing longer
        caroleMedia.setLooping(true);


        //create the media players objects
        docMedia = new MediaPlayer();
        docMedia  = MediaPlayer.create(this, R.raw.docantle);

        //looping the sound clip so its keeps playing longer
        docMedia.setLooping(true);


        //create the media players objects
        jeffMedia = new MediaPlayer();
        jeffMedia  = MediaPlayer.create(this, R.raw.jefflowe);

        //looping the sound clip so its keeps playing longer
        jeffMedia.setLooping(true);


        //create the media players objects
        erikMedia = new MediaPlayer();
        erikMedia  = MediaPlayer.create(this, R.raw.erikcowie);

        //looping the sound clip so its keeps playing longer
        erikMedia.setLooping(true);


        //create the media players objects
        johnMedia = new MediaPlayer();
        johnMedia  = MediaPlayer.create(this, R.raw.johnfinley);

        //looping the sound clip so its keeps playing longer
        johnMedia.setLooping(true);


    }//end onCreate


    /***************************************************************
     Function: doJoe

     Use:      Plays Joe media and paused all others if playing

     Returns:   nothing
     ***************************************************************/
    public void doJoe(View view)
    {
        if (joeMedia.isPlaying()) {
            //pause joe
            joeMedia.pause();
            //change the text
            joeBtn.setText("Play Joe");
        } else {
            if(caroleMedia.isPlaying()){
                caroleMedia.pause();
                carrelBtn.setText("Play Carole");
            }
            if(docMedia.isPlaying()){
                docMedia.pause();
                docBtn.setText("Play Doc");
            }
            if(jeffMedia.isPlaying()){
                jeffMedia.pause();
                jeffBtn.setText("Play Jeff");
            }
            if(erikMedia.isPlaying()){
                erikMedia.pause();
                erikBtn.setText("Play Erik");
            }
            if(johnMedia.isPlaying()){
                johnMedia.pause();
                johnBtn.setText("Play John");
            }
            joeMedia.start();

            //change the text again
            joeBtn.setText("Pause Joe");

        }
    }// end doJoe

    /***************************************************************
     Function: doCarrole

     Use:      Plays Carole media and paused all others if playing

     Returns:   nothing
     ***************************************************************/
    public void  doCarole(View view){
        if (caroleMedia.isPlaying()) {
            //pause joe
            caroleMedia.pause();
            //change the text
            carrelBtn.setText("Play Carole");
        } else {
            if(joeMedia.isPlaying()){
                joeMedia.pause();
                joeBtn.setText("Play Joe");
            }
            if(docMedia.isPlaying()){
                docMedia.pause();
                docBtn.setText("Play Doc");
            }
            if(jeffMedia.isPlaying()){
                jeffMedia.pause();
                jeffBtn.setText("Play Jeff");
            }
            if(erikMedia.isPlaying()){
                erikMedia.pause();
                erikBtn.setText("Play Erik");
            }
            if(johnMedia.isPlaying()){
                johnMedia.pause();
                johnBtn.setText("Play John");
            }

            caroleMedia.start();

            //change the text again
            carrelBtn.setText("Pause Husband Killer Carole");

        }

    }// end doCarole


    /***************************************************************
     Function: doDoc

     Use:      Plays Doc media and paused all others if playing

     Returns:   nothing
     ***************************************************************/
    public void doDoc(View view)
    {
        if (docMedia.isPlaying()) {
            //pause joe
            docMedia.pause();
            //change the text
            docBtn.setText("Play Doc");
        } else {
            if(caroleMedia.isPlaying()){
                caroleMedia.pause();
                carrelBtn.setText("Play Carole");
            }
            if(joeMedia.isPlaying()){
                joeMedia.pause();
                joeBtn.setText("Play Joe");
            }
            if(jeffMedia.isPlaying()){
                jeffMedia.pause();
                jeffBtn.setText("Play Jeff");
            }
            if(erikMedia.isPlaying()){
                erikMedia.pause();
                erikBtn.setText("Play Erik");
            }
            if(johnMedia.isPlaying()){
                johnMedia.pause();
                johnBtn.setText("Play John");
            }
            docMedia.start();

            //change the text again
            docBtn.setText("Pause Doc");

        }
    }// end doDoc

    /***************************************************************
     Function: doJeff

     Use:      Plays Jeff media and paused all others if playing

     Returns:   nothing
     ***************************************************************/
    public void doJeff(View view)
    {
        if (jeffMedia.isPlaying()) {
            //pause joe
            jeffMedia.pause();
            //change the text
            jeffBtn.setText("Play Jeff");
        } else {
            if(caroleMedia.isPlaying()){
                caroleMedia.pause();
                carrelBtn.setText("Play Carole");
            }
            if(joeMedia.isPlaying()){
                joeMedia.pause();
                joeBtn.setText("Play Joe");
            }
            if(erikMedia.isPlaying()){
                erikMedia.pause();
                erikBtn.setText("Play Erik");
            }
            if(johnMedia.isPlaying()){
                johnMedia.pause();
                johnBtn.setText("Play John");
            }
            if(docMedia.isPlaying()){
                docMedia.pause();
                docBtn.setText("Play Doc");
            }
            jeffMedia.start();

            //change the text again
            jeffBtn.setText("Pause Jeff");

        }
    }// end doJeff


    /***************************************************************
     Function: doErik

     Use:      Plays Erik media and paused all others if playing

     Returns:   nothing
     ***************************************************************/
    public void doErik(View view)
    {
        if (erikMedia.isPlaying()) {
            //pause joe
            erikMedia.pause();
            //change the text
            erikBtn.setText("Play Erik");
        } else {
            if(caroleMedia.isPlaying()){
                caroleMedia.pause();
                carrelBtn.setText("Play Carole");
            }
            if(joeMedia.isPlaying()){
                joeMedia.pause();
                joeBtn.setText("Play Joe");
            }
            if(johnMedia.isPlaying()){
                johnMedia.pause();
                johnBtn.setText("Play John");
            }
            if(docMedia.isPlaying()){
                docMedia.pause();
                docBtn.setText("Play Doc");
            }
            if(jeffMedia.isPlaying()){
                jeffMedia.pause();
                jeffBtn.setText("Play Jeff");
            }
            erikMedia.start();

            //change the text again
            erikBtn.setText("Pause Erik");

        }
    }// end doErik


    /***************************************************************
     Function: doJohn

     Use:      Plays John media and paused all others if playing

     Returns:   nothing
     ***************************************************************/
    public void doJohn(View view)
    {
        if (johnMedia.isPlaying()) {
            //pause joe
            johnMedia.pause();
            //change the text
            johnBtn.setText("Play John");
        } else {
            if(caroleMedia.isPlaying()){
                caroleMedia.pause();
                carrelBtn.setText("Play Carole");
            }
            if(joeMedia.isPlaying()){
                joeMedia.pause();
                joeBtn.setText("Play Joe");
            }
            if(docMedia.isPlaying()){
                docMedia.pause();
                docBtn.setText("Play Doc");
            }
            if(jeffMedia.isPlaying()){
                jeffMedia.pause();
                jeffBtn.setText("Play Jeff");
            }
            if(erikMedia.isPlaying()){
                erikMedia.pause();
                erikBtn.setText("Play Erik");
            }
            johnMedia.start();

            //change the text again
            johnBtn.setText("Pause John");

        }
    }// end doJohn
} //end main
